import React, { useState } from 'react';
import { tradingEngine } from '../../services/tradingEngine';
import { KeyRound, Server, CheckCircle2, Lock, AlertTriangle, ArrowRight, X } from 'lucide-react';

interface Mt5ConnectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
}

const COMMON_SERVERS = [
  'Exness-MT5Real9',
  'Exness-MT5Real14',
  'Exness-MT5Real7',
  'Exness-MT5Real10',
  'Exness-MT5Real8',
  'Exness-MT5Real',
  'HFMarketsGlobal-Live20',
  'HFMarketsSC-Live2',
  'ICMarketsSC-Live02',
  'ICMarketsSC-Live05',
  'ICMarketsAU-Live',
  'Deriv-Server',
  'XMGlobal-MT5',
  'FTMO-Server-Live',
  'Tickmill-Live01',
  'Pepperstone-Edge-Live',
];

export const Mt5ConnectionModal: React.FC<Mt5ConnectionModalProps> = ({
  isOpen,
  onClose,
  userId,
}) => {
  const masterAccount = tradingEngine.getMasterAccount();
  const [accountNumber, setAccountNumber] = useState('');
  const [brokerServer, setBrokerServer] = useState(COMMON_SERVERS[0]);
  const [password, setPassword] = useState('');
  const [isConnecting, setIsConnecting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsConnecting(true);

    try {
      if (!accountNumber || accountNumber.trim().length < 4) {
        throw new Error('Please enter a valid MT5 account login ID.');
      }
      if (!password) {
        throw new Error('Please enter MT5 account password.');
      }

      // Auto-normalize broker server if user input shorthand (e.g. Exness-Real9 -> Exness-MT5Real9)
      let targetServer = brokerServer.trim();
      const exnessMatch = targetServer.match(/^exness-?real(\d+)$/i);
      if (exnessMatch) {
        targetServer = `Exness-MT5Real${exnessMatch[1]}`;
        setBrokerServer(targetServer);
      }

      await tradingEngine.connectMt5Account(userId, accountNumber.trim(), targetServer, password);
      // Password is immediately discarded from memory
      setPassword('');
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 1500);
    } catch (err: any) {
      setErrorMsg(err.message || 'Connection failed.');
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm sm:max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden text-slate-100 animate-in zoom-in-95 duration-150">
        {/* Compact Header */}
        <div className="px-5 py-4 border-b border-slate-800 bg-gradient-to-r from-blue-600/15 via-slate-900 to-slate-900 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Server className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Connect MT5 Terminal</h3>
              <p className="text-[11px] text-slate-400">Replicating Main Master #{masterAccount.accountNumber}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5">
          {success ? (
            <div className="py-4 text-center space-y-2.5">
              <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-white">Terminal Authenticated & Linked</h4>
              <p className="text-xs text-slate-300">
                MT5 #{accountNumber} on <strong>{brokerServer}</strong> is verified. Live equity is syncing.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3.5">
              {errorMsg && (
                <div className="p-2.5 text-xs rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span className="leading-snug">{errorMsg}</span>
                </div>
              )}

              {/* Broker Server */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Broker Server Name
                </label>
                <div className="relative">
                  <Server className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
                  <input
                    type="text"
                    required
                    list="server-options"
                    value={brokerServer}
                    onChange={(e) => setBrokerServer(e.target.value)}
                    placeholder="e.g. Exness-MT5Real9 or ICMarketsSC-Live02"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl focus:border-blue-500 text-white font-mono"
                  />
                  <datalist id="server-options">
                    {COMMON_SERVERS.map((s) => (
                      <option key={s} value={s} />
                    ))}
                  </datalist>
                </div>
                {brokerServer.toLowerCase().includes('exness') && brokerServer.toLowerCase().includes('real') && !brokerServer.toLowerCase().includes('mt5') && (
                  <p className="text-[10px] text-blue-400 mt-1 font-mono">
                    Auto-resolves to: <strong className="text-white">{brokerServer.replace(/exness-?real(\d+)/i, 'Exness-MT5Real$1')}</strong>
                  </p>
                )}
              </div>

              {/* Login ID */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  MT5 Account Login ID
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
                  <input
                    type="text"
                    required
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    placeholder="e.g. 133227028"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl focus:border-blue-500 text-white font-mono"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  MT5 Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl focus:border-blue-500 text-white"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-1">
                <button
                  type="submit"
                  disabled={isConnecting}
                  className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 font-semibold text-xs text-white shadow-md shadow-blue-600/20 transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isConnecting ? (
                    <span>Verifying with Broker...</span>
                  ) : (
                    <>
                      <span>Verify Broker & Link Copier</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
